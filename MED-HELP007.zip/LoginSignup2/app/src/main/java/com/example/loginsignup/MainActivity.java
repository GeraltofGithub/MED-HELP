package com.example.loginsignup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.Intent;
import android.gesture.GestureOverlayView;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;


public class MainActivity extends AppCompatActivity {

    Menu mainmenumyprofile, mainmenumysettings, mainmenubookmarks, mainmenuhomepage;
    LinearLayout oxygencylinder, blooddonors, plasmadonors, hospitalbeds;
    EditText Searchbox;
    TextView ApiBox;
    ImageView Logoutbuttonfornow;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Logoutbuttonfornow = (ImageView) findViewById(R.id.imageMenu);


        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomnavigationview);

        bottomNavigationView.setSelectedItemId(R.id.Homepage);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.Homepage:
                        return true;
                    case R.id.SettingsApp:
                        startActivity(new Intent(getApplicationContext(), Settingspage.class));
                        overridePendingTransition(0, 0);
                        return true;
                }
                return false;
            }


        });

        Logoutbuttonfornow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),login_page.class));
                Toast.makeText(MainActivity.this, "Logged Out Successfully!", Toast.LENGTH_SHORT).show();
            }
        });

    }


    public void OxygenCylinderView(View view) {
        startActivity(new Intent(getApplicationContext(),RecyclerViewPostList.class));
    }

    public void timepasslogout(View view) {
        startActivity(new Intent(getApplicationContext(),login_page.class));
    }

    public void BloodDonorView(View view) {
        startActivity(new Intent(getApplicationContext(),recycler_post_list_blooddonor.class));
    }

    public void PlasmaDonorView(View view) {
        startActivity(new Intent(getApplicationContext(),recycler_post_list_plasmadonors.class));
    }

    public void HospitalView(View view) {
        startActivity(new Intent(getApplicationContext(),recycler_post_list_hospitalbeds.class));
    }
}


