package com.example.loginsignup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.NumberPicker;
import android.widget.Toast;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Objects;

public class NewNoteActivity extends AppCompatActivity {
    private EditText editTextTitlebox, editTextdescription;
    private NumberPicker numberPicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_note);



        editTextTitlebox = findViewById(R.id.titleedittext);
        editTextdescription = findViewById(R.id.descriptionedittext);
        numberPicker = findViewById(R.id.numberpicker);

        numberPicker.setMinValue(1);
        numberPicker.setMaxValue(10);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.new_post_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.savebutton:
                saveNote();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void saveNote(){
        String title = editTextTitlebox.getText().toString();
        String description = editTextdescription.getText().toString();
        int priority = numberPicker.getValue();

        if (title.trim().isEmpty() || description.trim().isEmpty()) {
            Toast.makeText(this,"Please insert a Title and description",Toast.LENGTH_SHORT).show();
            return;
        }

        CollectionReference postref = FirebaseFirestore.getInstance().collection("User's_Posts");
        postref.add(new Note(title,description,priority));
        Toast.makeText(this,"Post Created!",Toast.LENGTH_SHORT).show();
        finish();

    }


}