package com.example.loginsignup;

public class Note {
    private String title;
    private String description;
    private int prioritytimer;

    public Note(){
        //empty constructor
    }

    public Note(String title, String description, int prioritytimer) {
        this.title = title;
        this.description = description;
        this.prioritytimer = prioritytimer;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public int getPrioritytimer() {
        return prioritytimer;
    }
}
