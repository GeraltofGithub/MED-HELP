package com.example.loginsignup;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

public class NoteAdapterBD extends FirestoreRecyclerAdapter<NoteBloodDonors, NoteAdapterBD.NoteHolderBD> {


    public NoteAdapterBD(@NonNull FirestoreRecyclerOptions<NoteBloodDonors> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull NoteHolderBD noteHolderBD, int i, @NonNull NoteBloodDonors noteBloodDonors) {
        noteHolderBD.titleBD.setText(noteBloodDonors.getTitleBD());
        noteHolderBD.descriptionBD.setText(noteBloodDonors.getDescriptionBD());
        noteHolderBD.priorityBD.setText(String.valueOf(noteBloodDonors.getPrioritytimerBD()));
    }

    @NonNull
    @Override
    public NoteHolderBD onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.note_item_blooddonors,parent,false);
        return new NoteHolderBD(v);

    }

    class NoteHolderBD extends RecyclerView.ViewHolder {
        TextView titleBD;
        TextView descriptionBD;
        TextView priorityBD;

        public NoteHolderBD(View itemView){
            super(itemView);
            titleBD = itemView.findViewById(R.id.title_blood_donors);
            descriptionBD = itemView.findViewById(R.id.text_view_description_blooddonors);
            priorityBD = itemView.findViewById(R.id.priority_timer_blood_donors);
        }
    }


}
