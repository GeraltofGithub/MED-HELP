package com.example.loginsignup;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

public class NoteAdapterHB extends FirestoreRecyclerAdapter<NoteHospitalBeds, NoteAdapterHB.NoteHolderHB> {


    public NoteAdapterHB(@NonNull FirestoreRecyclerOptions<NoteHospitalBeds> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull NoteHolderHB noteHolderHB, int i, @NonNull NoteHospitalBeds noteHospitalBeds) {
        noteHolderHB.titleHB.setText(noteHospitalBeds.getTitleHB());
        noteHolderHB.descriptionHB.setText(noteHospitalBeds.getDescriptionHB());
        noteHolderHB.priorityHB.setText(String.valueOf(noteHospitalBeds.getPrioritytimerHB()));
    }

    @NonNull
    @Override
    public NoteHolderHB onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.note_item_hospitalbeds,parent,false);
        return new NoteHolderHB(v);
    }

    class NoteHolderHB extends RecyclerView.ViewHolder {
        TextView titleHB;
        TextView descriptionHB;
        TextView priorityHB;


        public NoteHolderHB(@NonNull View itemView) {
            super(itemView);
            titleHB = itemView.findViewById(R.id.title_hospital_beds);
            descriptionHB = itemView.findViewById(R.id.text_view_description_hospitalbeds);
            priorityHB = itemView.findViewById(R.id.priority_timer_hospital_beds);
        }
    }
}
