package com.example.loginsignup;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

public class NoteAdapterPD extends FirestoreRecyclerAdapter<NotePlasmaDonors, NoteAdapterPD.NoteHolderPD> {


    public NoteAdapterPD(@NonNull FirestoreRecyclerOptions<NotePlasmaDonors> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull NoteHolderPD noteHolderPD, int i, @NonNull NotePlasmaDonors notePlasmaDonors) {
        noteHolderPD.titlePD.setText(notePlasmaDonors.getTitlePD());
        noteHolderPD.descriptionPD.setText(notePlasmaDonors.getDescriptionPD());
        noteHolderPD.priorityPD.setText(String.valueOf(notePlasmaDonors.getPrioritytimerPD()));
    }

    @NonNull
    @Override
    public NoteHolderPD onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.note_item_plasmadonors,parent,false);
        return new NoteHolderPD(v);
    }

    class NoteHolderPD extends RecyclerView.ViewHolder {
        TextView titlePD;
        TextView descriptionPD;
        TextView priorityPD;

        public NoteHolderPD(View itemView){
            super(itemView);
                    titlePD = itemView.findViewById(R.id.title_plasma_donors);
                    descriptionPD = itemView.findViewById(R.id.text_view_description_plasmadonors);
                    priorityPD = itemView.findViewById(R.id.priority_timer_plasma_donors);
        }
    }

}
