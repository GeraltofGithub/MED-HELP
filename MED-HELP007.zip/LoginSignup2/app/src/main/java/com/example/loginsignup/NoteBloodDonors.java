package com.example.loginsignup;

public class NoteBloodDonors {
    private String titleBD;
    private String descriptionBD;
    private int prioritytimerBD;

    public NoteBloodDonors() {

    }

    public NoteBloodDonors(String titleBD, String descriptionBD, int prioritytimerBD) {
        this.titleBD = titleBD;
        this.descriptionBD = descriptionBD;
        this.prioritytimerBD = prioritytimerBD;
    }

    public String getTitleBD() {
        return titleBD;
    }

    public String getDescriptionBD() {
        return descriptionBD;
    }

    public int getPrioritytimerBD() {
        return prioritytimerBD;
    }
}
