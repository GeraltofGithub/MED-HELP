package com.example.loginsignup;

public class NoteHospitalBeds {
    public String titleHB;
    public String descriptionHB;
    private int prioritytimerHB;

    public NoteHospitalBeds(String titleHB, String descriptionHB, int prioritytimerHB) {
        this.titleHB = titleHB;
        this.descriptionHB = descriptionHB;
        this.prioritytimerHB = prioritytimerHB;
    }

    public String getTitleHB() {
        return titleHB;
    }

    public String getDescriptionHB() {
        return descriptionHB;
    }

    public int getPrioritytimerHB() {
        return prioritytimerHB;
    }
}
