package com.example.loginsignup;

public class NotePlasmaDonors {
    public String titlePD;
    public String descriptionPD;
    private int prioritytimerPD;

    public NotePlasmaDonors() {

    }

    public NotePlasmaDonors(String titlePD, String descriptionPD, int prioritytimerPD) {
        this.titlePD = titlePD;
        this.descriptionPD = descriptionPD;
        this.prioritytimerPD = prioritytimerPD;
    }

    public String getTitlePD() {
        return titlePD;
    }

    public String getDescriptionPD() {
        return descriptionPD;
    }

    public int getPrioritytimerPD() {
        return prioritytimerPD;
    }
}
