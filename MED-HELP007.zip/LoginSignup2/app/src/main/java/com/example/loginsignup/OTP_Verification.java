package com.example.loginsignup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.content.Intent;

import com.google.firebase.FirebaseException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class OTP_Verification extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_o_t_p__verification);

        final EditText inputMobile = findViewById(R.id.inputMobile);
        final Button buttonGetOTP = findViewById(R.id.buttonGetOTP);

        final ProgressBar progressBar = findViewById(R.id.progressbar1);

        buttonGetOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                if (inputMobile.getText().toString().trim().isEmpty()){
                    Toast.makeText(OTP_Verification.this, "Enter Mobile", Toast.LENGTH_SHORT).show();
                    return;
                }
                progressBar.setVisibility(View.VISIBLE);
                buttonGetOTP.setVisibility(View.INVISIBLE);


                PhoneAuthProvider.getInstance().verifyPhoneNumber(

                        "+91"+inputMobile.getText().toString(),
                        60,
                        TimeUnit.SECONDS,
                        OTP_Verification.this,
                  new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                      @Override
                      public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {

                      }

                      @Override
                      public void onVerificationFailed(@NonNull FirebaseException e) {
                          progressBar.setVisibility(View.GONE);
                          buttonGetOTP.setVisibility(View.VISIBLE);
                          Toast.makeText(OTP_Verification.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                      }

                      @Override
                      public void onCodeSent(@NonNull String verificationId, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                          progressBar.setVisibility(View.GONE);
                          buttonGetOTP.setVisibility(View.VISIBLE);
                          Intent intent = new Intent(getApplicationContext(), OTP_Verification2.class);
                          intent.putExtra("mobile", inputMobile.getText().toString());
                          intent.putExtra("verificationID", verificationId);
                          startActivity(intent);

                      }
                  }
                );

            }
        });

        
    }
}