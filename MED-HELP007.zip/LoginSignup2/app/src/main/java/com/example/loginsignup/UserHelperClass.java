package com.example.loginsignup;

public class UserHelperClass {

    String name, email, password, contactnumber, whatsappnumber, address;

    public UserHelperClass(String name, String email, String password, String contactnumber, String whatsappnumber, String address) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.contactnumber = contactnumber;
        this.whatsappnumber = whatsappnumber;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getContactnumber() {
        return contactnumber;
    }

    public void setContactnumber(String contactnumber) {
        this.contactnumber = contactnumber;
    }

    public String getWhatsappnumber() {
        return whatsappnumber;
    }

    public void setWhatsappnumber(String whatsappnumber) {
        this.whatsappnumber = whatsappnumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}






