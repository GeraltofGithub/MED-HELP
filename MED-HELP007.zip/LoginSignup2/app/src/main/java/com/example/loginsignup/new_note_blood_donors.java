package com.example.loginsignup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.NumberPicker;
import android.widget.Toast;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class new_note_blood_donors extends AppCompatActivity {

    private EditText TitleBloodDonors, DescriptionBloodDonors;
    private NumberPicker NumberPickerBloodDonors;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_note_blood_donors);

        TitleBloodDonors = findViewById(R.id.title_edit_text_blood_donors);
        DescriptionBloodDonors = findViewById(R.id.description_edit_text_blood_donors);
        NumberPickerBloodDonors = findViewById(R.id.number_picker_blood_donors);

        NumberPickerBloodDonors.setMinValue(1);
        NumberPickerBloodDonors.setMaxValue(10);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.new_post_menu_blooddonor,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.savebuttonblooddonor:
                savenotebd();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public void savenotebd(){
        String TitleBD = TitleBloodDonors.getText().toString();
        String DescriptionBD = DescriptionBloodDonors.getText().toString();
        int priority = NumberPickerBloodDonors.getValue();

        if (TitleBD.trim().isEmpty() || DescriptionBD.trim().isEmpty()) {
            Toast.makeText(this,"Please insert a Title and Description",Toast.LENGTH_SHORT).show();
            return;
        }

        CollectionReference postrefBD = FirebaseFirestore.getInstance().collection("User's_Posts_BloodDonors");
        postrefBD.add(new NoteBloodDonors(TitleBD,DescriptionBD,priority));
        Toast.makeText(this,"Post Created !",Toast.LENGTH_SHORT).show();
        finish();
    }

}