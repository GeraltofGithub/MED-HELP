package com.example.loginsignup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.NumberPicker;
import android.widget.Toast;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class new_note_hospitalbed extends AppCompatActivity {

    private EditText TitleHospitalBeds, DescriptionHospitalBeds;
    private NumberPicker NumberPickerHospitalBeds;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_note_hospitalbed);

        TitleHospitalBeds = findViewById(R.id.title_edit_text_hospital_beds);
        DescriptionHospitalBeds = findViewById(R.id.description_edit_text_hospital_beds);
        NumberPickerHospitalBeds = findViewById(R.id.number_picker_hospital_beds);

        NumberPickerHospitalBeds.setMaxValue(10);
        NumberPickerHospitalBeds.setMinValue(1);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.new_post_menu_hospitalbeds,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.savebuttonhospitalbeds:
                savenotehb();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public  void savenotehb(){
        String TitleHB = TitleHospitalBeds.getText().toString();
        String DescriptionHB = DescriptionHospitalBeds.getText().toString();
        int priority = NumberPickerHospitalBeds.getValue();

        if (TitleHB.trim().isEmpty() || DescriptionHB.trim().isEmpty()) {
            Toast.makeText(this, "Please insert a Title and Description !", Toast.LENGTH_SHORT).show();
        }

        CollectionReference postrefHB = FirebaseFirestore.getInstance().collection("User's Post Hospital Beds");
        postrefHB.add(new NoteHospitalBeds(TitleHB,DescriptionHB,priority));
        Toast.makeText(this, "Post Created !", Toast.LENGTH_SHORT).show();
        finish();
    }
}