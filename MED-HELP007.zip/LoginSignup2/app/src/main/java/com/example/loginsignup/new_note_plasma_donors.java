package com.example.loginsignup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.NumberPicker;
import android.widget.Toast;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class new_note_plasma_donors extends AppCompatActivity {

    private EditText TitlePlasmaDonors, DescriptionPlasmaDonors;
    private NumberPicker NumberPickerPlasmaDonors;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_note_plasma_donors);

        TitlePlasmaDonors = findViewById(R.id.title_edit_text_plasma_donors);
        DescriptionPlasmaDonors = findViewById(R.id.description_edit_text_plasma_donors);
        NumberPickerPlasmaDonors = findViewById(R.id.number_picker_plasma_donors);

        NumberPickerPlasmaDonors.setMinValue(1);
        NumberPickerPlasmaDonors.setMaxValue(10);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.new_post_menu_plasmadonors,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.savebuttonplasmadonors:
                savenotepd();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void savenotepd(){
        String TitlePD = TitlePlasmaDonors.getText().toString();
        String DescriptionPD = DescriptionPlasmaDonors.getText().toString();
        int priority = NumberPickerPlasmaDonors.getValue();

        if (TitlePD.trim().isEmpty() || DescriptionPD.trim().isEmpty()){
            Toast.makeText(this,"Please insert a Title and Description !",Toast.LENGTH_SHORT).show();
            return;
        }

        CollectionReference postrefPD = FirebaseFirestore.getInstance().collection("User's Post PlasmaDonors");
        postrefPD.add(new NotePlasmaDonors(TitlePD,DescriptionPD,priority));
        Toast.makeText(this,"Post Created !",Toast.LENGTH_SHORT).show();
        finish();
    }

}