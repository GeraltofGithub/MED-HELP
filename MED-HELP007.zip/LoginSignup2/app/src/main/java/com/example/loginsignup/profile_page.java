package com.example.loginsignup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class profile_page extends AppCompatActivity {

    TextInputEditText pfullname, pemailid, pwnumber, pcnumber, ppassword;
    Button pupdatebtn, plogoutbtn;
    ImageView pmedhelplogo;
    TextView p_yourprofile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_page);

        pfullname = findViewById(R.id.Full_name2);
        pemailid = findViewById(R.id.emailid2);
        pwnumber = findViewById(R.id.whatsappnumber);
        pcnumber = findViewById(R.id.contactnumber);
        ppassword = findViewById(R.id.passwordprofilepage);
        pupdatebtn = findViewById(R.id.UpdateButton);
        plogoutbtn = findViewById(R.id.button111);
        p_yourprofile = findViewById(R.id.Full_name);

        plogoutbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),login_page.class));
            }
        });


        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomnavigationview);

        bottomNavigationView.setSelectedItemId(R.id.AccountProfile);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener(){
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem){
                switch (menuItem.getItemId()){
                    case R.id.AccountProfile:
                        return true;
                    case R.id.Homepage:
                        startActivity(new Intent(getApplicationContext(),MainActivity.class));
                        overridePendingTransition(0,0);
                        return true;
                }
                return false;
            }


        });

    }
}


