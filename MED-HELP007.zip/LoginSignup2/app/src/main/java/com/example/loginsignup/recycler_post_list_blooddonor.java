package com.example.loginsignup;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import android.os.Bundle;

public class recycler_post_list_blooddonor extends AppCompatActivity {

    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference rootnoderef = db.collection("User's_Posts_BloodDonors");
    private NoteAdapterBD adapterBD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_post_list_blooddonor);

        FloatingActionButton buttonaddnoteBD = findViewById(R.id.button_add_post_blood_donors);
        buttonaddnoteBD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(recycler_post_list_blooddonor.this,new_note_blood_donors.class));
            }
        });

        setUpRecyclerView();
    }
    public void setUpRecyclerView(){
        Query query = rootnoderef.orderBy("prioritytimerBD",Query.Direction.DESCENDING);
        FirestoreRecyclerOptions<NoteBloodDonors> options = new FirestoreRecyclerOptions.Builder<NoteBloodDonors>()
                .setQuery(query, NoteBloodDonors.class)
                .build();
        adapterBD = new NoteAdapterBD(options);

        RecyclerView recyclerView = findViewById(R.id.recycler_view_blood_donor);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapterBD);
    }

    @Override
    protected void onStart() {
        super.onStart();
        adapterBD.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapterBD.stopListening();
    }
}