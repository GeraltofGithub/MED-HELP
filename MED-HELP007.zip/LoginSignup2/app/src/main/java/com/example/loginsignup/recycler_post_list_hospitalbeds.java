package com.example.loginsignup;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

public class recycler_post_list_hospitalbeds extends AppCompatActivity {

    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference rootnoderef = db.collection("User's Post Hospital Beds");
    private NoteAdapterHB adapterHB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_post_list_hospitalbeds);

        FloatingActionButton buttonaddnotehb = findViewById(R.id.button_add_post_hospital_beds);
        buttonaddnotehb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(recycler_post_list_hospitalbeds.this,new_note_hospitalbed.class));
            }
        });
        setUpRecyclerView();
    }
    public void setUpRecyclerView(){
        Query query = rootnoderef.orderBy("prioritytimerHB", Query.Direction.DESCENDING);
        FirestoreRecyclerOptions<NoteHospitalBeds> options = new FirestoreRecyclerOptions.Builder<NoteHospitalBeds>()
                .setQuery(query, NoteHospitalBeds.class)
                .build();
        adapterHB = new NoteAdapterHB(options);

        RecyclerView recyclerView = findViewById(R.id.recycler_view_hospital_beds);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapterHB);

    }

    @Override
    protected void onStart() {
        super.onStart();
        adapterHB.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapterHB.stopListening();
    }
}