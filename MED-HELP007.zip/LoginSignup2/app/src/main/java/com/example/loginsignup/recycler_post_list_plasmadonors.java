package com.example.loginsignup;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

public class recycler_post_list_plasmadonors extends AppCompatActivity {

    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference rootnoderefPD = db.collection("User's_Posts_PlasmaDonors");
    private NoteAdapterPD adapterPD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_post_list_plasmadonors);

        FloatingActionButton buttonaddnotePD = findViewById(R.id.button_add_post_plasma_donors);
        buttonaddnotePD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(recycler_post_list_plasmadonors.this,new_note_plasma_donors.class));
            }
        });
        setUpRecyclerView();
    }
    public void setUpRecyclerView(){
        Query query = rootnoderefPD.orderBy("prioritytimerPD", Query.Direction.DESCENDING);
        FirestoreRecyclerOptions<NotePlasmaDonors> options = new FirestoreRecyclerOptions.Builder<NotePlasmaDonors>()
                .setQuery(query,NotePlasmaDonors.class)
                .build();
        adapterPD = new NoteAdapterPD(options);

        RecyclerView recyclerView = findViewById(R.id.recycler_view_plasma_donor);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapterPD);
    }
    @Override
    protected void onStart() {
        super.onStart();
        adapterPD.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapterPD.stopListening();
    }

}