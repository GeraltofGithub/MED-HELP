package com.example.settingpage;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button AppPolicy=findViewById(R.id.Apppolicy);
        Button logout= findViewById(R.id.Logout);

        AppPolicy.setOnClickListener(this);
        logout.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.Apppolicy:
                Toast.makeText(this,"Medhelp",Toast.LENGTH_SHORT).show();
                break;
            case R.id.Logout:
                Intent intentL= new Intent(MainActivity.this,Login.class);
                startActivity(intentL);
                finish();
                Toast.makeText(this,"Successfully Logout!",Toast.LENGTH_SHORT).show();
                break;
        }

    }
}
